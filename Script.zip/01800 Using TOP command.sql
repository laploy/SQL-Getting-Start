/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- TOP PERCENT
USE Northwind
GO

SELECT COUNT (*) FROM Orders;
GO

-- The Orders table has 830 rows, and 1 percent of 830 is 8.3
SELECT TOP (1) PERCENT orderid, CustomerID, orderdate
FROM Orders
ORDER BY orderdate DESC, orderid DESC;
GO



----------------------------------------------------------------
-- Select bottom rows
USE Northwind
GO

SELECT SupplierID, CompanyName, ContactName, Address, City
FROM (SELECT TOP 5 * FROM Suppliers ORDER BY SupplierID DESC) AS s
ORDER BY SupplierID  ASC;
GO


-----------------------------------------------------------------
-- TOP and Input Expressions
USE Northwind
GO

SELECT COUNT (DISTINCT YEAR(orderdate)) AS "Number of year" 
FROM orders;
GO

SELECT TOP (SELECT COUNT (DISTINCT YEAR(orderdate))FROM orders)
	orderid, 
	orderdate, 
	CustomerID, 
	EmployeeID
FROM Orders
GO


-----------------------------------------------------------------
--  TOP and Modifications
USe AdventureWorks2019
GO

SELECT TOP 5 
	Title, 
	FirstName, 
	LastName 
INTO #T
FROM Person.Person
  WHERE Title = 'Ms.';
  GO

SELECT * FROM #T
GO

DROP TABLE #T;
GO


-----------------------------------------------------------------
-- TOP and variable
USE pubs
GO

SELECT * FROM publishers
ORDER BY pub_id;
GO

SELECT * FROM publishers
ORDER BY pub_id
	OFFSET 3 ROWS 
	FETCH NEXT 4 ROWS ONLY;
GO












