/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Counting the Records in a Table
USE AdventureWorks2019
GO

SELECT COUNT(*) FROM Person.Person;
GO

SELECT COUNT(FirstName) FROM Person.Person;
GO

SELECT COUNT(*) FROM Person.Person
WHERE Title = 'Mr.';
GO

---------------------------------------------------
-- Using DISTINCT with COUNT
USE AdventureWorks2019
GO

SELECT COUNT(DISTINCT FirstName) AS 'Number of distinct name'
FROM Person.Person;
GO

USE Northwind
GO

SELECT COUNT(DISTINCT SupplierID) AS 'Number of Supplier' 
FROM Products;
GO

---------------------------------------------------
-- Column Aliases
USE AdventureWorks2019
GO

SELECT TOP 10
	p.ProductID AS [Product ID],
	p.Name,
	pd.Description AS [Product Description],
	p.ListPrice AS [Price list]
FROM Production.Product AS p
	JOIN Production.ProductModel as pm 
		ON p.ProductModelID = pm.ProductModelID
	JOIN Production.ProductModelProductDescriptionCulture pmpc
		ON pm.ProductModelID = pmpc.ProductModelID
	JOIN Production.ProductDescription pd
		ON pd.ProductDescriptionID = pmpc.ProductDescriptionID;
GO


---------------------------------------------------
-- Using column alias in the ORDER BY cause
USE pubs
GO

SELECT TOP 5 title_id, type, title FROM titles
	ORDER BY title;
GO

SELECT title_id, type, title AS aa FROM titles
	ORDER BY aa;
GO



---------------------------------------------------
-- Using Like and underscore
USE AdventureWorks2019
GO

-- all name with Nut
SELECT TOP 5 ProductID, ProductNumber, Name, Color
	FROM Production.Product
	WHERE Name LIKE '%Nut%'
GO

-- all name with 4 letters and Nut
SELECT TOP 5 ProductID, ProductNumber, Name, Color
	FROM Production.Product
	WHERE Name LIKE '____Nut%'
GO


