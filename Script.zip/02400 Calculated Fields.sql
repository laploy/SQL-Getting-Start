/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Mathematical Calculations
/*
	Mathematical Operators Available in SQL
		Addition		+
		Subtraction		-
		Multiplication	*
		Division		/
		Remainder		%
*/

USE AdventureWorks2019;
GO

SELECT
	SalesOrderID, 
	OrderQty, 
	UnitPrice, 
	LineTotal,
	OrderQty * UnitPrice LineTotal2,
	LineTotal / OrderQty UnitPrice2,
	LineTotal / UnitPrice OrderQty2
FROM Sales.SalesOrderDetail;
GO

-------------------------------------------------------------------
-- Getting remainder

SELECT
	7 * 5 AS multiply,
	(7 * 5) + 3 AS multiplyPlus,
	38 % 5 AS Remainder;

/*
	Remainder of dividing the price of each product, 
	converted to an integer value, into the number of products ordered.
*/

USE AdventureWorks2019;
GO
  
SELECT TOP(100)
	ProductID, UnitPrice, OrderQty,
	UnitPrice / OrderQty AS Devide,
	CAST((UnitPrice) AS INT) % OrderQty AS Modulo  
FROM Sales.SalesOrderDetail;  
GO


-------------------------------------------------------------------
-- String Operations

USE AdventureWorks2019;
GO

SELECT TOP(100)
	ProductID, UnitPrice, OrderQty,
	LineTotal,
	CONCAT('Total: ', LineTotal) AS String1,
	CONCAT_WS(': ', 'Total', OrderQty * UnitPrice) AS String2,
	'Total: ' + CONVERT(varchar(12), LineTotal) AS String3


FROM Sales.SalesOrderDetail;  
GO


-------------------------------------------------------------------
-- Literal Values

USE AdventureWorks2019;
GO

SELECT TOP(100)
	ProductID, UnitPrice, OrderQty,
	'Box' AS Package
FROM Sales.SalesOrderDetail;  
GO


-------------------------------------------------------------------
-- Calculate with Condition 

USE AdventureWorks2019;
GO

SELECT TOP(100)
	ProductID, UnitPrice, OrderQty, LineTotal,
	CASE 
		WHEN OrderQty > 2 THEN CAST((LineTotal / 10) AS INT)
		ELSE NULL
	END AS '10% Discount'
FROM Sales.SalesOrderDetail;  
GO


-------------------------------------------------------------------
-- Compute from 2 tables column

USE AdventureWorks2019;
GO

SELECT 
	soh.SalesOrderID, 
	soh.TaxAmt,
	sod.LineTotal,
	sod.LineTotal + soh.TaxAmt AS 'Total+Tax'
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.SalesOrderDetail AS sod
	ON soh.SalesOrderID = sod.SalesOrderID
WHERE soh.SalesOrderID = 43659;
GO




