/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Insert a row with NULL
-- Column Age is omitted
USE mytest
GO

INSERT INTO Student(ID, Name, Sex, Phone)
VALUES ('013', 'Jan', 'F', '0840705544');
GO

SELECT * FROM Student;
GO

---------------------------------------
-- Insert a row with Space in column Sex
USE mytest
GO

INSERT INTO Student(ID, Name, Sex, Age, Phone)
VALUES ('016', 'Bob', '', 11, '0940702233');
GO

SELECT * FROM Student;
GO

---------------------------------------
-- Creat a table 
USE mytest;
GO

CREATE TABLE Student2 (
    ID varchar(5) NOT NULL,
    Name varchar(20) NULL,
    Sex varchar(1)  NULL,
    Age int  NULL,
    Phone varchar(10)
);
GO

-- Insert OK
INSERT INTO Student2(ID, Name, Sex, Age, Phone)
VALUES ('010', 'Alice', 'F', 10, '0840704040');
GO
SELECT * FROM Student2;
GO

-- Age is omitted, OK
INSERT INTO Student2(ID, Name, Sex, Phone)
VALUES ('011', 'Ted', 'M', '2236654556');
SELECT * FROM Student2;
GO

-- ID is omitted, ERROR
INSERT INTO Student2(Name, Sex, Age, Phone)
VALUES ('Bob', 'M', 12, '0998676754');
GO
SELECT * FROM Student2;
GO

---------------------------------------
-- Create table with default value
USE mytest
GO

DROP TABLE Student2;
GO

CREATE TABLE Student2 (
    ID varchar(5),
    Name varchar(20),
    Sex varchar(1),
    Age int,
    City varchar(10) DEFAULT 'Bangkok'
);
GO

---------------------------------------
-- Insert data into check constraint table
USE mytest
GO

INSERT INTO Student2(ID, Name, Sex, Age, City)
VALUES ('010', 'Alice', 'F', 10, 'Boston');

INSERT INTO Student2(ID, Name, Sex, Age, City)
VALUES ('011', 'Ted', 'M', 11, 'Berlin');

INSERT INTO Student2(ID, Name, Sex, Age)
VALUES ('012', 'Bob', 'M', 12);

INSERT INTO Student2(ID, Name, Sex, Age, City)
VALUES ('017', 'Sara', 'F', 9, 'Tokyo');

INSERT INTO Student2(ID, Name, Sex, Age, City)
VALUES ('032', 'Wendy', 'F', 8, 'Paris');
GO


---------------------------------------
-- Create table with Check constraint
USE mytest
GO

DROP TABLE Student2;
GO

CREATE TABLE Student2 (
    ID varchar(5),
    Name varchar(20),
    Sex varchar(1),
    Age int CHECK (Age<=12),
    City varchar(10) 
);
GO


---------------------------------------
--  Insert data into check constraint table
USE mytest
GO

-- OK
INSERT INTO Student2(ID, Name, Sex, Age, City)
VALUES ('010', 'Alice', 'F', 11, 'Boston');
GO

SELECT * FROM Student2;
GO

-- OK
INSERT INTO Student2(ID, Name, Sex, Age, City)
VALUES ('011', 'Ted', 'M', 12, 'Berlin');
GO

SELECT * FROM Student2;
GO

-- ERROR Age is too hight
INSERT INTO Student2(ID, Name, Sex, Age, City)
VALUES ('012', 'Bob', 'M', 13, 'Bangokok');
GO

SELECT * FROM Student2;
GO



---------------------------------------
-- Create table with Primary key
USE mytest
GO

DROP TABLE Student2;
GO

CREATE TABLE Student2 (
    ID varchar(5)NOT NULL PRIMARY KEY,
    Name varchar(20),
    Sex varchar(1),
    Age int,
    City varchar(10) 
);
GO


---------------------------------------
--  Insert data into table with primary key
USE mytest
GO

-- OK
INSERT INTO Student2(ID, Name, Sex, Age, City)
VALUES ('010', 'Alice', 'F', 11, 'Boston');
GO

SELECT * FROM Student2;
GO

-- OK
INSERT INTO Student2(ID, Name, Sex, Age, City)
VALUES ('011', 'Ted', 'M', 12, 'Berlin');
GO

SELECT * FROM Student2;
GO

-- ERROR ID is not UNIQUE values
INSERT INTO Student2(ID, Name, Sex, Age, City)
VALUES ('010', 'Bob', 'M', 13, 'Bangokok');
GO

SELECT * FROM Student2;
GO

















