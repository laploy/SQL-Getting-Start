/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Self-Contained Scalar Subquery
USE AdventureWorks2019
GO

DECLARE @maxid AS INT = 
	(SELECT MAX(SalesOrderID)
	FROM Sales.SalesOrderHeader);

SELECT
	SalesOrderID
	,orderdate 
	,SalesPersonID ,CustomerID
FROM Sales.SalesOrderHeader
WHERE SalesOrderID = @maxid;
GO


----------------------------------------------
-- Simple subquery example

USE AdventureWorks2019;
GO

SELECT
	s.ProductID
	,s.OrderQty
	,s.UnitPrice
FROM(
		SELECT * 
		FROM Sales.SalesOrderDetail
	) AS s
WHERE s.OrderQty > 35;
GO


----------------------------------------------
-- Simple suqbuery with JOIN command
USE pubs
GO

SELECT *
FROM (
		SELECT
			t.title_id, t.title, a.au_lname, 
			a.city AS [author city], 
			p.pub_name, p.city AS [publisher city]
		FROM titles AS t
			JOIN titleauthor AS ti ON t.title_id = ti.title_id
			JOIN authors AS a ON ti.au_id = a.au_id
			JOIN publishers AS p ON t.pub_id = p.pub_id
	) AS pt
WHERE pt.[publisher city] = 'Berkeley';
GO


----------------------------------------------
-- Self-Contained Scalar Subquery
USE AdventureWorks2019
GO

DECLARE @maxid AS INT = 
	(SELECT MAX(SalesOrderID)
	FROM Sales.SalesOrderHeader);

SELECT
	SalesOrderID
	,orderdate 
	,SalesPersonID ,CustomerID
FROM Sales.SalesOrderHeader
WHERE SalesOrderID = @maxid;
GO




----------------------------------------------
-- Self-Join VS Subquery
USE AdventureWorks2019
GO

/* SELECT statement built using a subquery. */
SELECT [Name]
FROM Production.Product
WHERE ListPrice =
    (SELECT ListPrice
     FROM Production.Product
     WHERE [Name] = 'Chainring Bolts' );
GO

/* SELECT statement built using a join that returns
   the same result set. */
SELECT Prd1.[Name]
FROM Production.Product AS Prd1
     JOIN Production.Product AS Prd2
       ON (Prd1.ListPrice = Prd2.ListPrice)
WHERE Prd2.[Name] = 'Chainring Bolts';
GO



----------------------------------------------
-- Qualifying column names in subqueries
USE AdventureWorks2019
GO

/* 
BusinessEntityID column (line 11) is implicitly qualified
by the table name in the outer query FROM clause (line 10)
*/
SELECT BusinessEntityID, Name, SalesPersonID
FROM Sales.Store
WHERE BusinessEntityID NOT IN
    (SELECT CustomerID
     FROM Sales.Customer
     WHERE TerritoryID = 5);
GO

-- Fully qualifying column names
SELECT BusinessEntityID, Name, SalesPersonID
FROM Sales.Store
WHERE Sales.Store.BusinessEntityID NOT IN
    (SELECT Sales.Customer.CustomerID
     FROM Sales.Customer
     WHERE TerritoryID = 5);
GO




----------------------------------------------
-- Multiple levels of nestin
USE AdventureWorks2019
GO

-- get employees who are also sales persons
SELECT LastName, FirstName
FROM Person.Person
WHERE BusinessEntityID IN
    (SELECT BusinessEntityID
     FROM HumanResources.Employee
     WHERE BusinessEntityID IN
        (SELECT BusinessEntityID
         FROM Sales.SalesPerson)
    );
GO












