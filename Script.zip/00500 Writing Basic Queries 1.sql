/*
    Getting started SQL 
    Loy Vanich 2021
*/


--Selecting a Limited Number of Columns
USE pubs
GO

-- Select all column
SELECT TOP 5 * FROM employee
GO

-- Get same specificted column
SELECT  TOP 5 fname, lname, job_id  FROM employee
GO

----------------------------------------------------
-- Ordering the Results
USE pubs
GO

-- order by job id
SELECT TOP 5 * FROM employee
	ORDER BY job_id;
GO

-- order by fname
SELECT TOP 5 * FROM employee
	ORDER BY fname;
GO


----------------------------------------------------
-- Ordering Using Field Abbreviations
USE pubs
GO

-- order by job id
SELECT TOP 5 * FROM employee
	ORDER BY 5;
GO

-- order by fname
SELECT TOP 5 * FROM employee
	ORDER BY 2 DESC;
GO

----------------------------------------------------
-- Ordering by Multiple Columns
USE pubs
GO

-- no order
SELECT * FROM publishers;
GO

-- order one column
SELECT * FROM publishers
	ORDER BY country;
GO

-- order multiple columns
SELECT * FROM publishers
	ORDER BY country, pub_name;
GO

----------------------------------------------------
-- Putting Conditions with WHERE
USE pubs
GO

-- no condition
SELECT TOP 10 * FROM titles;
GO

SELECT TOP 10 * FROM titles
	WHERE price > 20;
GO

----------------------------------------------------
-- Combining the WHERE and ORDER BY
USE pubs
GO

SELECT TOP 10 * FROM titles
	WHERE price > 18
	ORDER BY price;
GO






