/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Connecting to a Database
USE mytest
GO

SELECT TOP 5 * FROM Student
GO

-- Connecting to other Database
USE pubs
GO

SELECT TOP 5 * FROM titles
GO


------------------------------------
-- Checking the Database Server Version
-- @@Version - Transact SQL Configuration Functions
SELECT @@version;
GO

SELECT @@SERVERNAME;
GO

SELECT @@SERVICENAME;
GO


------------------------------------
-- Checking the Database Name
USE mytest
GO

SELECT DB_NAME() AS [Current Database];  
GO 

-- Connecting to other Database
USE pubs
GO

SELECT DB_NAME() AS [Current Database];  
GO 


------------------------------------
--Checking Your Username
SELECT USER_NAME();
GO

SELECT TOP 5 name, type_desc
FROM master.sys.database_principals;
GO


------------------------------------
-- Show all table's name
SELECT TABLE_NAME FROM
  pubs.INFORMATION_SCHEMA.TABLES
WHERE
  TABLE_TYPE = 'BASE TABLE';
GO


------------------------------------
-- Insert row from another table
USE mytest;
GO

CREATE TABLE new_employee (
    emp_id char(9),
	fname varchar(20),
	lname varchar(30)
);
GO

INSERT INTO new_employee (emp_id, fname, lname)
	SELECT TOP 5 emp_id, fname, lname FROM pubs.dbo.employee;
GO

SELECT * FROM new_employee;
GO


------------------------------------




