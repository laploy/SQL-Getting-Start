/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Create a view
USE AdventureWorks2019
GO

CREATE VIEW dbo.v_Product_TransactionHistory AS
	SELECT
		p.Name AS ProductName,
		p.ProductNumber,
		pc.Name AS ProductCategory,
		ps.Name AS ProductSubCategory,
		pm.Name AS ProductModel,
		th.TransactionID,
		th.ReferenceOrderID,
		th.ReferenceOrderLineID,
		th.TransactionDate,
		th.TransactionType,
		th.Quantity,
		th.ActualCost,
		th.Quantity * th.ActualCost AS ExtendedPrice
	FROM Production.TransactionHistory th
		INNER JOIN Production.Product p
		ON th.ProductID = p.ProductID
	INNER JOIN Production.ProductModel pm
		ON pm.ProductModelID = p.ProductModelID
	INNER JOIN Production.ProductSubcategory ps
		ON ps.ProductSubcategoryID = p.ProductSubcategoryID
	INNER JOIN Production.ProductCategory pc
		ON pc.ProductCategoryID = ps.ProductCategoryID
	WHERE pc.Name = 'Bikes';
GO


-----------------------------------------------------------------
-- Querying data from a View

USE AdventureWorks2019;
GO

SELECT 
	ProductName,
	ProductNumber,
	ReferenceOrderID,
	ActualCost
FROM dbo.v_Product_TransactionHistory
ORDER BY ProductName;
GO



-----------------------------------------------------------------
-- Modifying Data Through a View
USE AdventureWorks2019;
GO

SELECT
	ProductName,
	ProductNumber,
	ReferenceOrderID,
	Quantity,
	ActualCost,
	ExtendedPrice
FROM dbo.v_Product_TransactionHistory
WHERE ReferenceOrderID = 53463
GO

UPDATE dbo.v_Product_TransactionHistory
SET Quantity = 3
WHERE ReferenceOrderID = 53463;
GO


-----------------------------------------------------------------
-- Querying a View’s Definition
USE AdventureWorks2019;
GO

SELECT definition
FROM sys.sql_modules AS sm
WHERE object_id = OBJECT_ID('dbo.v_Product_TransactionHistory');
GO
SELECT OBJECT_DEFINITION(OBJECT_ID('dbo.v_Product_TransactionHistory'));
GO
EXECUTE sp_helptext 'dbo.v_Product_TransactionHistory';
GO


-----------------------------------------------------------------
-- Obtaining a List of All Views in a Database
USE AdventureWorks2019;
GO

SELECT
	OBJECT_SCHEMA_NAME(v.object_id) AS SchemaName,
	v.name
FROM sys.views AS v ;
GO

SELECT 
	OBJECT_SCHEMA_NAME(o.object_id) AS SchemaName,
	o.name
FROM sys.objects AS o
WHERE o.type = 'V' ;
GO



-----------------------------------------------------------------
-- Obtaining a List of All Columns in a View
USE AdventureWorks2019;
GO

SELECT 
	column_id,
	name
FROM sys.columns
WHERE object_id = OBJECT_ID('dbo.v_Product_TransactionHistory');
GO











