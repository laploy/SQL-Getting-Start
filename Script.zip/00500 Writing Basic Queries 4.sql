/*
    Getting started SQL 
    Loy Vanich 2021
*/


-----------------------------------------------------------------
-- Keeping the WHERE Clause Unambiguous
USE pubs
GO

SElECT * FROM employee
	WHERE LEFT(fname, 1) = 'A' OR  LEFT(fname, 1) = 'M' AND job_id > 10;
GO

SElECT * FROM employee
	WHERE (LEFT(fname, 1) = 'A' OR  LEFT(fname, 1) = 'M') AND job_id > 10;
GO


------------------------------------------------------------
-- Testing for Existence
USE pubs
GO

SElECT TOP (1) 'Found!' FROM employee WHERE job_lvl > 10;
GO

SElECT TOP (1) 'Found!'  FROM employee WHERE job_lvl > 300;
GO

SELECT 'Found!'  WHERE EXISTS (
	SELECT * FROM employee WHERE job_lvl > 200
);


------------------------------------------------------------
-- Specifying a Range of Values
USE pubs
GO

--SElECT TOP (10) * FROM employee;
--GO

SElECT TOP (10) * FROM employee
	WHERE job_lvl BETWEEN 40 AND 80;
GO

------------------------------------------------------------
-- Checking for Null Values
USE pubs
GO

SELECT * FROM discounts;
GO

SELECT * FROM discounts WHERE stor_id IS NULL;
GO

SELECT * FROM discounts WHERE stor_id IS NOT NULL;
GO


------------------------------------------------------------
-- Writing an IN-List
USE pubs
GO

--SELECT * FROM publishers;
--GO

SELECT * FROM publishers
	WHERE country IN ('USA', 'Germany');
GO


------------------------------------------------------------
-- Performing Wildcard Searches
USE pubs
GO

SELECT * FROM employee WHERE fname LIKE 'an%'
GO

SELECT * FROM employee WHERE fname LIKE 'ro%'
GO

SELECT * FROM employee WHERE fname LIKE 'le%'
GO



------------------------------------------------------------
-- Get table row count

USE Northwind
GO

SELECT COUNT(*) FROM [Order Details];
GO

