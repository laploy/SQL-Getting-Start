/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Specifying the Case-Sensitivity of a Sort
SELECT TOP (1000) [ID]
      ,[Name]
      ,[SubDistrict]
      ,[District]
      ,[Province]
  FROM [ThaiTest].[dbo].[Farmer]

    SELECT TOP 10 * FROM Farmer
	WHERE Name LIKE N'%แสน%'
	ORDER BY Name 

  SELECT TOP 10 * FROM Farmer
	WHERE Name LIKE N'%แสน%'
	ORDER BY Name COLLATE Thai_CI_AI_WS ASC
GO

-- SELECT Name, Description FROM fn_helpcollations();

---------------------------------------
 -- Using CASE command
 
 USE ThaiTest
 GO

 SELECT SUBSTRING(Name,1,25) AS Name, Province, Capita,
	CASE
		WHEN Capita = 0 THEN N'ศูนย์'
		WHEN Capita IS NULL THEN  N'ไม่มีข้อมูล'
		ELSE 'OK'
	END AS Note
	FROM Factory
	ORDER BY Capita
 GO
 
 
 ---------------------------------------
  -- Sorting NULL
 USE ThaiTest
 GO

 SELECT SUBSTRING(Name,1,25) AS Name, Province, Capita
	FROM Factory
	ORDER BY 
		CASE 
			WHEN Capita IS NULL 
				THEN 0
				ELSE 1
		END;
 GO


---------------------------------------
-- Force Forcing Unusual Sort Orders
--		Want to sort by color and RED color is on top
USE AdventureWorks2019
GO

SELECT 
	p.ProductID, p.Name, p.Color
	FROM Production.Product AS p
		WHERE p.Color IS NOT NULL
		ORDER BY 
			CASE p.Color
				WHEN 'Red' THEN ''
				ELSE p.COLOR
		END;
GO


---------------------------------------
-- Paging Through a Result Set

USE AdventureWorks2019
GO

SELECT  ProductID, ProductNumber, Name 
	FROM Production.Product
	ORDER BY ProductNumber
	OFFSET 293 ROWS FETCH NEXT 10 ROWS ONLY;
GO


---------------------------------------
-- Sampling a Subset of Rows
/* 
	The TABLESAMPLE clause is available from SQL Server 2008 R2 forward. 
	Use it to get an idea of what the data looks like in a table without 
	having to page through all of the table’s data.
*/

USE AdventureWorks2019
GO

SELECT * FROM Production.Product
	TABLESAMPLE (100 ROWS);
GO

SELECT * FROM Production.Product
	TABLESAMPLE (5 PERCENT);
GO







