/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Rounding

DECLARE @v1 money = 123.456;
DECLARE @v2 float = 123.456;
DECLARE @v3 decimal(6,3) = 123.456;

SELECT
	@v1 sample1,
	@v2 sample2,
	@v3 sample3
UNION ALL
SELECT
	ROUND(@v1, 2),
	ROUND(@v2, 2),
	ROUND(@v3, 2);


USE AdventureWorks2019
GO

SELECT 
	EndOfDayRate,
	ROUND(EndOfDayRate,0) AS EODR1,
	ROUND(EndOfDayRate,2) AS EODR2
FROM Sales.CurrencyRate;
GO



------------------------------------------------------
-- Rounding Always Up or Down

DECLARE @v1 decimal(6,3) = 123.345;
DECLARE @v2 decimal(6,3) = 123.567;
DECLARE @v3 decimal(6,3) = 123.789;

SELECT
	@v1 sample1, @v2 sample2, @v3 sample3
UNION ALL
SELECT
	ROUND(@v1, 0), ROUND(@v2, 0), ROUND(@v3, 0)
UNION ALL
SELECT
	CEILING(@v1), CEILING(@v2), CEILING(@v3)
UNION ALL
SELECT
	FLOOR(@v1), FLOOR(@v2), FLOOR(@v3);
GO



------------------------------------------------------
-- Discarding Decimal Places

DECLARE @v1 decimal(6,3) = 123.345;
DECLARE @v2 decimal(6,3) = 123.567;
DECLARE @v3 decimal(6,3) = 123.789;

SELECT
	@v1 sample1, @v2 sample2, @v3 sample3
UNION ALL
SELECT
	ROUND(@v1, 0, 1), ROUND(@v2, 0, 1), ROUND(@v3, 0, 1)
UNION ALL
SELECT
	ROUND(@v1, 1, 1), ROUND(@v2, 1, 1), ROUND(@v3, 1, 1)
UNION ALL
SELECT
	ROUND(@v1, -1, 1), ROUND(@v2, -1, 1), ROUND(@v3, -1, 1)
GO



------------------------------------------------------
-- Testing Equality of Binary Floating-Point Values

DECLARE @r1 real = 0.95
DECLARE @f1 float = 0.95

-- r1 - r2 is not zero
SELECT @r1 r1, 	@f1 f2, @r1-@f1 'r1-f1';

-- using ABS function to remove sign
SELECT 	
	ABS(@r1) r1, ABS(@f1) f2, ABS(@r1-@f1) 'r1-f1';

-- if r1 - f1 is less than 0 then it is not
IF ABS(@r1-@f1) < 0
	SELECT 'Equal'
ELSE
	SELECT 'Not Equal';

-- if r1 - f1 is less than .1 then it is equal
IF ABS(@r1-@f1) < 0.1
	SELECT 'Equal'
ELSE
	SELECT 'Not Equal';


------------------------------------------------------
-- Treating Nulls as Zeros
DECLARE @v1 INT = 123;
DECLARE @v2 decimal(6, 3) = 123.456;
DECLARE @v3 INT;

SELECT @v1 v1, @v2 v2, @v3 v3
UNION ALL
-- replace NULL with zero
SELECT
	COALESCE(@v1, 0), COALESCE(@v2, 0), COALESCE(@v3, 0);
GO

CREATE TABLE #T(v1 INT, v2 INT, v3 INT);
INSERT INTO #T VALUES 
	(12, 13, 14), (22, NULL, 24), (32, 33, 34);

SELECT v1, v2, v3 FROM #T;

SELECT 
	COALESCE(v1 ,0) v1, 
	COALESCE(v2, 0) v2, 
	COALESCE(v3,0) v3
FROM #T;

DROP TABLE #T;
GO

USE AdventureWorks2019
GO

SELECT
	SpecialOfferID, 
	MaxQty, 
	COALESCE(MaxQty, 0) AS MaxQtyAlt
FROM Sales.SpecialOffer;
GO

------------------------------------------------------
-- Generating Random Integers in a Row Set
USE AdventureWorks2019
GO

DECLARE @rmin int, @rmax int;
SET @rmin = 900;
SET @rmax = 1000;
SELECT Name,
	NEWID() newid,
	CHECKSUM(NEWID()) 'check',
	RAND(CHECKSUM(NEWID())) 'rand check',
	CAST(RAND(CHECKSUM(NEWID())) * 
	(@rmax-@rmin) AS INT) + @rmin AS random
FROM Production.Product;
GO


------------------------------------------------------
--Generating sequential number column

USE AdventureWorks2019
GO

SELECT  
	ProductID, Name, ProductNumber 
FROM Production.Product  
WHERE Name LIKE '%nut%' ;  
GO

CREATE SCHEMA Samples ;  
GO  


-- AdventureWorks2019/Programmablility
--	/Sequences/Samples.IDLabel  
CREATE SEQUENCE Samples.IDLabel  
    AS tinyint  
    START WITH 1  
    INCREMENT BY 1 ;  
GO  
  
SELECT 
	NEXT VALUE FOR Samples.IDLabel 
	OVER (ORDER BY Name) AS NutID, 
	ProductID, Name, ProductNumber 
FROM Production.Product  
WHERE Name LIKE '%nut%' ;  
GO

DROP SEQUENCE Samples.IDLabel;
GO
DROP SCHEMA IF EXISTS Samples;
GO













