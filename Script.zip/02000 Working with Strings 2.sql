/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Counting Characters or Bytes in a String

SELECT LEN('Hello, World!')
GO

DECLARE @v1 VARCHAR(40) = 'Hello, World!';
DECLARE @v2 CHAR(40) = 'Hello, World!';
SELECT LEN(@v1) AS 'data', DATALENGTH(@v1);
SELECT LEN(@v2) AS 'data', DATALENGTH(@v2);
GO

SELECT LEN( N'Hello, World!');
GO

USE Northwind
GO

SELECT TOP 10 
	SupplierID, ContactName, Address, City, 
	LEN(City) AS 'City Len'
FROM Suppliers;
GO

SELECT TOP 10 
	SupplierID, ContactName, Address, City, 
	LEN(City) AS 'City Len'
FROM Suppliers
WHERE LEN(City) > 9;
GO


-------------------------------------------------------------
--Replacing Part of a String
SELECT REPLACE('The Classic history.', 'Classic', 'Vintage');
GO

USE Northwind
GO

SELECT TOP 5
	SupplierID, ContactName, Address, City
	,REPLACE(City, 'Tokyo', 'Bangkok') AS 'New City'
FROM Suppliers;
GO

SELECT TOP 5
	SupplierID, ContactName, Address
	,REPLACE(ContactName, 'C', 'K') AS 'New Name'
FROM Suppliers;
GO

-------------------------------------------------------------
-- Stuffing a String into a String

SELECT STUFF ('Come to Thailand and enjoy!', 9, 8, 'Laos');
GO

DECLARE @v1 VARCHAR(40) =  'Come to Thailand and enjoy!';
SELECT @v1, STUFF ( @v1, 9, 8, 'Laos' );
GO

USE Northwind
GO

DECLARE @v1 VARCHAR(40) =  'Hogwarts';
SELECT TOP 5
	SupplierID, ContactName, Address
	,STUFF ( Address, 5, 6, @v1) AS [New Address]
FROM Suppliers
WHERE Address LIKE '____Oxford%';
GO


-------------------------------------------------------------
-- Changing Between Lowercase and Uppercase

DECLARE @v1 VARCHAR(40) =  'Come to Thailand and enjoy!';
SELECT @v1, LOWER('Come to Thailand and enjoy!');
SELECT @v1, UPPER('Come to Thailand and enjoy!');
GO

USE Northwind
GO

DECLARE @v1 VARCHAR(40) =  'Hogwarts';
SELECT TOP 5
	SupplierID, ContactName, City
	,LOWER(City) AS [Lower]
	,UPPER(City) AS [Upper]
FROM Suppliers
GO


-------------------------------------------------------------
-- Removing Leading and Trailing Blanks

DECLARE @v1 VARCHAR(40) =  ' Hello ';
SELECT 'abc' + @v1 + 'def', 'abc' + LTRIM(@v1) + 'def';
SELECT 'abc' + @v1 + 'def', 'abc' + RTRIM(@v1) + 'def';
SELECT 'abc' + @v1 + 'def', 'abc' + LTRIM(RTRIM(@v1)) + 'def';
GO

USE Northwind
GO

DECLARE @v1 VARCHAR(40) =  ' Hogwarts';
SELECT TOP 5
	SupplierID, ContactName, City
	,City + @v1
	,City + LTRIM(@v1)
FROM Suppliers
GO


-------------------------------------------------------------
--Repeating an Expression N Times
SELECT REPLICATE ('*', 30);
GO

USE Northwind
GO

SELECT TOP 10
	SupplierID, ContactName, 
	CASE
		WHEN SupplierID IN (1,4,8) THEN 
			(SELECT '<' + REPLICATE ('-', 10))
		ELSE ''
	END AS 'Arrow',
	City
FROM Suppliers
GO



-------------------------------------------------------------
-- Repeating a Blank Space N Times

DECLARE @animals TABLE
	(
		string1 VARCHAR(20),
		string2 VARCHAR(20),
		string3 VARCHAR(20)
	);

INSERT @animals
	VALUES	('elephant', 'dog', 'giraffe'),
			('kitty', 'puppy', 'ant'),
			('chicken', 'fish', 'marmacet');

SELECT string1, string2, string3 FROM @animals;

SELECT string1 + string2 + string3 FROM @animals;

SELECT string1 + SPACE(10) + string2 + SPACE(10) + string3 
FROM @animals;

SELECT CONCAT(string1, SPACE(20 - LEN(string1)),
			string2, SPACE(20 - LEN(string2)),
			string3, SPACE(20 - LEN(string3)))
		AS formatted_string
FROM @animals;
GO

-------------------------------------------------------------
-- Reversing the Order of Characters in a String
SELECT REVERSE('Hello World');
GO

USE ThaiTest
GO

SELECT physical_name
FROM sys.database_files;
GO

SELECT 
	physical_name,
	Revers = REVERSE(physical_name)
FROM sys.database_files;
GO

SELECT 
	Path = LEFT(physical_name, LEN(physical_name) -
		CHARINDEX('\', REVERSE(physical_name)) + 1),
	FileName = RIGHT(physical_name, 
		CHARINDEX('\', REVERSE(physical_name)) - 1)
FROM sys.database_files;
GO














