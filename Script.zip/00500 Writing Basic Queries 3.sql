/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Naming the Output Columns
USE mytest
GO

SELECT TOP (10)  ID, Name, Sex, Age, Phone FROM Student;
GO

SELECT TOP (10)  ID, Name, Sex AS Gender, Age, Phone FROM Student;
GO

-----------------------------------------------------------------
-- Providing Shorthand Names for Tables
SElECT TOP (5) * FROM pubs.dbo.employee;
GO

SElECT TOP (5) E.emp_id, E.fname, e.job_lvl
	FROM pubs.dbo.employee AS E
	WHERE E.job_lvl < 100;
GO

-----------------------------------------------------------------
-- Computing New Columns from Existing Data
SElECT TOP (5) * FROM pubs.dbo.employee;
GO

SElECT TOP (5) E.emp_id, E.fname, e.job_lvl,
	job_lvl * job_id AS 'Salary'
	FROM pubs.dbo.employee AS E
	WHERE E.job_lvl < 100;
GO


-----------------------------------------------------------------
-- Negating a Search Condition
SElECT TOP (5) * FROM pubs.dbo.employee
	WHERE job_lvl = 35;
GO

SElECT TOP (5) * FROM pubs.dbo.employee
	WHERE NOT job_lvl = 35;
GO



