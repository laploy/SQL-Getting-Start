/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Displaying the Integer Representations for Parts of a Date

USE AdventureWorks2019
GO

SELECT 
	DISTINCT(ProductID), 
	ModifiedDate,
DATEPART(YEAR, ModifiedDate) AS [Year],
DATEPART(MONTH, ModifiedDate) AS [Month],
DATEPART(DAY, ModifiedDate) AS [Day]
FROM Production.ProductInventory
WHERE ProductID IN (531, 530, 997);
GO


-------------------------------------------------------------
-- Determining Whether a String Is a Valid Date

USE AdventureWorks2019
GO

SELECT 
	DISTINCT(ProductID), 
	ModifiedDate,
	ISDATE(ModifiedDate) AS 'Is a date'
FROM Production.ProductInventory
WHERE ProductID IN (531, 530, 997);
GO

SELECT
	MyData,
	ISDATE(MyData) AS 'Is a date'
FROM
	( VALUES 
		( 'IsThisADate'),
		( '40'),
		( '2021/02/14'),
		( '2021-02-14'),
		( '2021-02-40'),
		( '2012-13-01') ) dt (MyData);
GO



-------------------------------------------------------------
-- Determining the Last Day of the Month

USE AdventureWorks2019
GO

SELECT 
	GETDATE(), 
	EOMONTH(GETDATE()) AS 'Last day';
GO

SELECT 
	DISTINCT(ProductID), 
	ModifiedDate,
	DATEPART(YEAR, ModifiedDate) AS [Year],
	DATEPART(MONTH, ModifiedDate) AS [Month],
	DATEPART(DAY, ModifiedDate) AS [Day],
	DATEPART(DAY, EOMONTH(ModifiedDate)) AS [Last Day]
FROM Production.ProductInventory
WHERE ProductID IN (531, 530, 997);
GO



-------------------------------------------------------------
-- Creating a Date from Numbers
SELECT
	'DateFromParts' AS ConversionType,
	DATEFROMPARTS(2012, 8, 15) AS [Value];

SELECT 
	'TimeFromParts' AS ConversionType,
	TIMEFROMPARTS(18, 25, 32, 5, 1) AS [Value];

SELECT 
	'SmallDateTimeFromParts' AS ConversionType,
	SMALLDATETIMEFROMPARTS(2012, 8, 15, 18, 25) AS [Value];

SELECT 
	'DateTimeFromParts' AS ConversionType,
	DATETIMEFROMPARTS(2012, 8, 15, 18, 25, 32, 450) AS [Value];

SELECT 
	'DateTime2FromParts' AS ConversionType,
	DATETIME2FROMPARTS(2012, 8, 15, 18, 25, 32, 5, 7) AS [Value];

SELECT
	'DateTimeOffsetFromParts' AS ConversionType,
	DATETIMEOFFSETFROMPARTS(2012, 8, 15, 18, 25, 32, 5, 4, 0, 7) AS [Value];
GO



-------------------------------------------------------------
-- Finding the Beginning Date of a Datepart

DECLARE @MyDate DATETIME2 = '2021-01-01T18:25:42.9999999';
DECLARE @Base DATETIME = '2000-01-01T00:00:00';

SELECT 
MyDate,
	DATEADD(YEAR, DATEDIFF(YEAR, @Base, MyDate), @Base) AS [FirstDayOfYear],
	DATEADD(MONTH, DATEDIFF(MONTH, @Base, MyDate), @Base) AS [FirstDayOfMonth],
	DATEADD(QUARTER,DATEDIFF(QUARTER, @Base, MyDate), @Base) AS [FirstDayOfQuarter]
FROM 
	(VALUES 
	('2015-01-17T00:00:00'),
	('2016-11-23T00:00:00'),
	('2017-07-09T00:00:00'),
	('2018-07-11T00:00:00'),
	('2019-01-05T00:00:00'),
	('2020-11-27T00:00:00'),
	('2021-08-03T00:00:00')) dt (MyDate);
/* --------------------- */
SELECT 
	'StartOfHour' AS ConversionType,
	DATEADD(HOUR, DATEDIFF(HOUR, @Base, @MyDate), @Base) AS DateResult
UNION ALL
SELECT
	'StartOfMinute',
	DATEADD(MINUTE, DATEDIFF(MINUTE, @Base, @MyDate), @Base)
UNION ALL
SELECT 
	'StartOfSecond',
	DATEADD(SECOND, DATEDIFF(SECOND, @Base, @MyDate), @Base);
GO


-------------------------------------------------------------
-- Finding total for each month


USE AdventureWorks2019
GO

SELECT
	YEAR(ModifiedDate) as SalesYear,
	FORMAT(SUM(UnitPrice * OrderQty), 'c') 
		AS 'Yearly Total'
FROM Sales.SalesOrderDetail
GROUP BY YEAR(ModifiedDate)
ORDER BY YEAR(ModifiedDate);
GO

SELECT
	YEAR(ModifiedDate) as SalesYear,
	MONTH(ModifiedDate) as SalesMonth,
	FORMAT(SUM(UnitPrice * OrderQty), 'c')
		AS 'Monthly total'
FROM Sales.SalesOrderDetail
WHERE YEAR(ModifiedDate) = '2014'
GROUP BY YEAR(ModifiedDate), MONTH(ModifiedDate)
ORDER BY YEAR(ModifiedDate), MONTH(ModifiedDate);
GO



-------------------------------------------------------------------
-- Get first day of the week

DECLARE @myList TABLE(myDay VARCHAR(40)); 
INSERT INTO @myList VALUES 
	('2021-05-05'), ('2021-05-12'), 
	('2021-05-19'), ('2021-05-26');

SELECT 
	DATEADD(wk, 0, DATEADD
		(DAY, 1-DATEPART(WEEKDAY, myDay), 
		DATEDIFF(dd, 0, myDay))) AS 'Date',
	DATENAME(Day,
		DATEADD(wk, 0, DATEADD
		(DAY, 1-DATEPART(WEEKDAY, myDay), 
		DATEDIFF(dd, 0, myDay)))) AS 'First Date',
	DATENAME(WEEKDAY,
		DATEADD(wk, 0, DATEADD
		(DAY, 1-DATEPART(WEEKDAY, myDay), 
		DATEDIFF(dd, 0, myDay)))) AS 'Week Day'	
FROM @myList;
GO


-------------------------------------------------------------------
-- Finding days of the week

--first day previous week
SELECT 
	DATEADD(wk, -1, DATEADD(DAY, 1-DATEPART(WEEKDAY, GETDATE()), 
		DATEDIFF(dd, 0, GETDATE())));

--first day current week
SELECT 
	DATEADD(wk, 0, DATEADD(DAY, 1-DATEPART(WEEKDAY, GETDATE()), 
		DATEDIFF(dd, 0, GETDATE()))); 

--first day next week
SELECT 
	DATEADD(wk, 1, DATEADD(DAY, 1-DATEPART(WEEKDAY, GETDATE()), 
		DATEDIFF(dd, 0, GETDATE()))); 

--last day previous week
SELECT 
	DATEADD(wk, 0, DATEADD(DAY, 0-DATEPART(WEEKDAY, GETDATE()), 
		DATEDIFF(dd, 0, GETDATE()))); 

--last day current week
SELECT 
	DATEADD(wk, 1, DATEADD(DAY, 0-DATEPART(WEEKDAY, GETDATE()), 
		DATEDIFF(dd, 0, GETDATE()))); 

--last day next week
SELECT 
	DATEADD(wk, 2, DATEADD(DAY, 0-DATEPART(WEEKDAY, GETDATE()), 
		DATEDIFF(dd, 0, GETDATE()))); 
































