/*
    Getting started SQL 
    Loy Vanich 2021
*/


--01900 Using APPLY command


-- Concatenating Multiple Strings
USE Northwind
GO

SELECT SupplierID, CompanyName, ContactName, Address, City
FROM Suppliers
WHERE CompanyName LIKE 'Big%'
GO

SELECT CompanyName + ', ' + ContactName as [Company and Contact]
FROM Suppliers
WHERE CompanyName LIKE 'Big%'
GO

SELECT [Company and Contact] = CONCAT(CompanyName, ', ', ContactName) 
FROM Suppliers
WHERE CompanyName LIKE 'Big%'
GO


-----------------------------------------------------------------------
-- Finding a Character’s ASCII Value
USE Northwind
GO

SELECT SupplierID, CompanyName, ContactName, Address, City
FROM Suppliers
GO

SELECT ASCII('B'), ASCII('e'), ASCII('n'), ASCII('d');
GO

SELECT SupplierID, CompanyName, ContactName, Address, City
FROM Suppliers
WHERE City = CHAR(66) +  CHAR(101) + CHAR(110) + CHAR(100);
GO


-----------------------------------------------------------------------
-- Returning Integer and Character Unicode Values
USE ThaiTest
GO

SELECT TOP 5 * FROM Farmer;
GO

SELECT UNICODE(N'ธ'), UNICODE(N'า');
GO

SELECT NCHAR(3608), NCHAR(3634);
GO

SELECT * FROM Farmer
WHERE Name LIKE NCHAR(3608) +  NCHAR(3634) + '%'
GO


-----------------------------------------------------------------------
-- Locating Characters in a String
SELECT CHARINDEX('bro','Quick brow fox jump ove');
GO

USE AdventureWorks2019
GO

SELECT AddressID, AddressLine1, City
FROM Person.Address
WHERE AddressLine1 LIKE '%Olive%'
GO

-- get any row with Olive and zero at the front
SELECT AddressID, AddressLine1, City, 
	PATINDEX('%[0]%Olive%', AddressLine1) AS 'Index'
FROM Person.Address
WHERE PATINDEX('%[0]%Olive%', AddressLine1) > 0;
GO


-----------------------------------------------------------------------
-- Determining the Similarity of Strings
USE AdventureWorks2019
GO

SELECT DISTINCT
	LastName
FROM Person.Person
WHERE SOUNDEX(LastName) = SOUNDEX('Smith');
GO

SELECT DIFFERENCE('Smith','Schmidt');
GO

-- 0 = low similarity 4 = high similarity
SELECT DISTINCT
	LastName
FROM Person.Person
WHERE DIFFERENCE(LastName, 'Smith') = 4;
GO


-----------------------------------------------------------------------
-- Returning the Leftmost or Rightmost Portion of a String

SELECT LEFT('Quick brow fox jump over a lazy dog.', 10);
GO

SELECT RIGHT('Quick brow fox jump over a lazy dog.', 10);
GO

USE AdventureWorks2019
GO

SELECT TOP (5) ProductNumber, Name
FROM Production.Product;

GO
SELECT TOP (5) ProductNumber, ProductName = LEFT(Name, 10)
FROM Production.Product;
GO


-----------------------------------------------------------------------
-- Create new column using CONCAT, REPLICATE and RIGHT
USE AdventureWorks2019
GO

SELECT TOP (5) CustomerID, StoreID, AccountNumber
FROM Sales.Customer;
GO

SELECT TOP (5)
	CustomerID, StoreID, AccountNumber,
	'Store Account' = CONCAT('SA', RIGHT(REPLICATE('0', 8)
	+ CAST(StoreID AS VARCHAR(10)), 8))
FROM Sales.Customer;
GO


-----------------------------------------------------------------------
-- Returning Part of a String
USE AdventureWorks2019
GO

SELECT TOP (3)
	PhoneNumber,
	AreaCode = LEFT(PhoneNumber, 3),
	Exchange = SUBSTRING(PhoneNumber, 5, 3)
FROM Person.PersonPhone
WHERE PhoneNumber LIKE 
	'[0-9][0-9][0-9]-[0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]';
GO


















