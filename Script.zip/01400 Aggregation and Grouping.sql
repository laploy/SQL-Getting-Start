/*
    Getting started SQL 
    Loy Vanich 2021
*/



--------------------------------------------------------------
-- Aggregate Functions
USE AdventureWorks2019
GO

SELECT Rating, Comments FROM Production.ProductReview;
GO

SELECT
	MIN(Rating) Rating_Min,
	MAX(Rating) Rating_Max,
	SUM(Rating) Rating_Sum,
	AVG(Rating) Rating_Avg
FROM Production.ProductReview;
GO


--------------------------------------------------------------
-- Aggregations product orders
USE AdventureWorks2019
GO

SELECT TOP (12) SalesOrderID, ProductID, OrderQty, LineTotal
FROM [Sales].[SalesOrderDetail];
GO

SELECT TOP (5)
	SalesOrderID,
	SUM(LineTotal) AS OrderTotal,
	MIN(LineTotal) AS MinLine,
	MAX(LineTotal) AS MaxLine,
	AVG(LineTotal) AS AvgLine,
	COUNT(LineTotal) AS CountLine
FROM [Sales].[SalesOrderDetail]
	GROUP BY SalesOrderID
GO



--------------------------------------------------------------
-- Counting the Rows in a Group
USE AdventureWorks2019
GO

SELECT TOP (5) * 
FROM Production.ProductInventory
ORDER BY Shelf;
GO

SELECT TOP (5)
	Shelf,
	COUNT(ProductID) AS [Row count]
FROM Production.ProductInventory
GROUP BY Shelf
ORDER BY Shelf;
GO


--------------------------------------------------------------
-- Restricting a Result Set to Groups of Interest
USE AdventureWorks2019
GO

SELECT TOP 5 *
FROM Production.ScrapReason s
	INNER JOIN Production.WorkOrder w
	ON s.ScrapReasonID = w.ScrapReasonID;
GO

SELECT
	s.Name,
	COUNT(w.WorkOrderID) AS [Count]
FROM Production.ScrapReason s
	INNER JOIN Production.WorkOrder w
	ON s.ScrapReasonID = w.ScrapReasonID
GROUP BY s.Name
HAVING COUNT(*) < 50;
GO

--------------------------------------------------------------
-- Performing Aggregations against Unique Values Only
USE AdventureWorks2019
GO

SELECT
	FORMAT([RateChangeDate],'MMM dd yyyy') AS Date,
	COUNT([Rate]) AS [Rate count],
	COUNT(DISTINCT Rate) AS [Rate distinctCount]
FROM [HumanResources].[EmployeePayHistory]
WHERE RateChangeDate >= '2008-12-01'
	AND RateChangeDate < '2008-12-10'
GROUP BY RateChangeDate;
GO


--------------------------------------------------------------
-- Creating Hierarchical Summaries
USE AdventureWorks2019
GO

SELECT 
	i.Shelf,
	p.Name,
	SUM(i.Quantity) AS Total
FROM Production.ProductInventory i
	INNER JOIN Production.Product p
		ON i.ProductID = p.ProductID
WHERE i.Shelf IN ('A','B')
	AND p.Name LIKE 'Metal%'
GROUP BY ROLLUP(i.Shelf, p.Name);
GO

