/*
    Getting started SQL 
    Loy Vanich 2021
*/


PRINT 'Hello world.';

---------------------------------------
-- Hello world loop
DECLARE @i INT;
SET @i = 0;

WHILE @i < 5
BEGIN
   PRINT 'Hello world.';
   SET @i = @i + 1;
END;

---------------------------------------
-- Create a database
USE master;
GO

CREATE DATABASE mytest;
GO

---------------------------------------
-- Check if database is already there

USE master;
GO

IF DB_ID (N'mytest') IS NOT NULL
    PRINT N'myTest database is exits';  
ELSE  
    PRINT N'There is no myTest database'; 
	
---------------------------------------
-- Delete a database

USE master;
GO

DROP DATABASE mytest;
GO

---------------------------------------
-- Create a database. Drop if already exits

USE master;
GO

IF DB_ID (N'mytest') IS NOT NULL
DROP DATABASE mytest;
GO

CREATE DATABASE mytest;
GO

-- Verify the database files and sizes
SELECT name, size, size*1.0/128 AS [Size in MBs]
FROM sys.master_files
WHERE name = N'mytest';
GO

---------------------------------------
-- Creat a table 

USE mytest;
GO

CREATE TABLE Student (
    ID varchar(5),
    Name varchar(20),
    Sex varchar(1),
    Age int,
    Phone varchar(10)
);
GO

---------------------------------------
-- Delete a table

USE mytest
GO

DROP TABLE Student;
GO

---------------------------------------
-- Insert a row to table

USE mytest
GO

INSERT INTO Student(ID, Name, Sex, Age, Phone)
VALUES ('010', 'Alice', 'F', 10, '0840704040');
GO

---------------------------------------
-- delete all row

USE mytest
GO

DELETE FROM Student;
GO

------------------------------------
-- delete specificed row

USE mytest
GO

DELETE FROM Student
	WHERE Name = 'Alice';
GO

---------------------------------------
-- Insert multiple rows

USE mytest
GO

INSERT INTO Student(ID, Name, Sex, Age, Phone)
VALUES ('010', 'Alice', 'F', 10, '0840704040');

INSERT INTO Student(ID, Name, Sex, Age, Phone)
VALUES ('011', 'Ted', 'M', 11, '2236654556');

INSERT INTO Student(ID, Name, Sex, Age, Phone)
VALUES ('012', 'Bob', 'M', 12, '0998676754');

INSERT INTO Student(ID, Name, Sex, Age, Phone)
VALUES ('017', 'Sara', 'F', 9, '0998787656');

INSERT INTO Student(ID, Name, Sex, Age, Phone)
VALUES ('032', 'Wendy', 'F', 8, '0232345435');

GO

---------------------------------------
-- show all column

USE mytest
GO

-- get all row and column
SELECT * FROM Student

-- get all row and column
SELECT TOP 2 * FROM Student

---------------------------------------
-- show  specifiedd column

USE mytest
GO

-- get first 3 columns
SELECT ID, Name, Sex FROM Student

-- column list could be any order
SELECT Phone, Age, Name FROM Student

---------------------------------------
-- Get data with condition

USE mytest
GO

-- get all girl
SELECT * FROM Student
	WHERE Sex = 'F';

-- get all boy
SELECT * FROM Student
	WHERE Sex = 'M';
	
---------------------------------------
---------------------------------------



