/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Replacing NULL with an Alternate Value
USE AdventureWorks2019
GO

SELECT ProductID, ProductNumber, Name, Color,
		[Color Description] = ISNULL(Color, 'Smoke')
	FROM Production.Product
	WHERE ProductID BETWEEN 319 AND 325
GO

--------------------------------------------------------------
-- Using COALESCE function

USE AdventureWorks2019
GO

SELECT C.CustomerID
	   ,COALESCE(s.Name, p.FirstName) as 'Customer'
	   ,s.Name
	   ,p.FirstName
	  FROM Sales.Customer c
	   LEFT JOIN Person.Person p ON C.PersonID = p.BusinessEntityID
	   LEFT JOIN SALES.Store s ON C.StoreID = s.BusinessEntityID;
GO



--------------------------------------------------------------
-- 'IS NULL' and '= NULL'

DECLARE @value INT = NULL;

SELECT
	CASE WHEN @value = NULL THEN 1
		WHEN @value <> NULL THEN 2
		WHEN @value IS NULL THEN 3
		ELSE 4
	END
GO
----------------------------------------
DECLARE @value INT = 123;

SELECT
	CASE WHEN @value = NULL THEN 1
		WHEN @value <> NULL THEN 2
		WHEN @value IS NULL THEN 3
		ELSE 4
	END
GO


--------------------------------------------------------------
-- Using NULLIF function
USE AdventureWorks2019
GO

SELECT ProductID, ProductNumber, Name, Color,
		[Color Description] = NULLIF(Color, 'black')
	FROM Production.Product
	WHERE ProductID BETWEEN 319 AND 325
GO


