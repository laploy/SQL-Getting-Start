/*
    Getting started SQL 
    Loy Vanich 2021
*/


--Representing Integers

DECLARE @bip bigint, @bin bigint
DECLARE @ip int, @in int
DECLARE @sip smallint, @sin smallint
DECLARE @ti tinyint

SET @bip = 9223372036854775807 /* 2^63-1 */
SET @bin = -9223372036854775808 /* -2^63 */
SET @ip = 2147483647 /* 2^31-1 */
SET @in = -2147483648 /* -2^31 */
SET @sip = 32767 /* 2^15-1 */
SET @sin = -32768 /* -2^15 */
SET @ti = 255 /* 2^8-1 */

SELECT 'bigint' AS type_name, @bip AS max_value, @bin AS min_value
UNION ALL
SELECT 'int', @ip, @in
UNION ALL
SELECT 'smallint', @sip, @sin
UNION ALL
SELECT 'tinyint', @ti, 0
ORDER BY max_value ASC;
GO


--------------------------------------------------------
-- Creating Single-Bit Integers
---- store 8 variable in to 1 byte
DECLARE @myBit BIT
DECLARE @myBitStr NCHAR(5)
 
 -- No value assigned
SELECT @myBit AS  [Bit value], @myBitStr AS String

-- Assign value 1
SET @myBitStr=1;
SET @myBit=@myBitStr;
SELECT @myBit AS [Bit value], @myBitStr AS String;

-- Assign value 0
SET @myBitStr=0;
SET @myBit=@myBitStr;
SELECT @myBit AS [Bit value], @myBitStr AS String;

--TRUE is converted to 1
SET @myBitStr='TRUE'
SET @myBit=@myBitStr
SELECT @myBit AS  [Bit value], @myBitStr AS String

--FALSE is converted to 0
SET @myBitStr='FALSE'
SET @myBit=@myBitStr
SELECT @myBit AS  [Bit value], @myBitStr AS String
 
--Assigning any other string value causes an error
--SET @myBitStr='YES'
--SET @myBit=@myBitStr --<====== error
 GO


--------------------------------------------------------
-- Representing Decimal and Monetary Amounts
DECLARE @x0 decimal(7,0) = 1234567.
DECLARE @x1 decimal(7,1) = 123456.7
DECLARE @x2 decimal(7,2) = 12345.67
DECLARE @x3 decimal(7,3) = 1234.567
DECLARE @x4 decimal(7,4) = 123.4567
DECLARE @x5 decimal(7,5) = 12.34567
DECLARE @x6 decimal(7,6) = 1.234567
DECLARE @x7 decimal(7,7) = .1234567
DECLARE @x8 decimal(14,7) = 1234567.1234567

SELECT @x0 AS 'Result' UNION ALL
SELECT @x1 UNION ALL
SELECT @x2 UNION ALL
SELECT @x3 UNION ALL
SELECT @x4 UNION ALL
SELECT @x5 UNION ALL
SELECT @x6 UNION ALL
SELECT @x7 UNION ALL
SELECT @x8;
GO


--------------------------------------------------------
--   Representing Floating-Point Values
DECLARE @x1 real; /* same as float(24) */
DECLARE @x2 float; /* same as float(53) */
DECLARE @x3 float(53);
DECLARE @x4 float(24);



--------------------------------------------------------
-- Writing Mathematical Expressions
DECLARE @cur_bal decimal(7,2) = 94235.49;
DECLARE @new_bal decimal(7,2);
DECLARE @temp decimal(7,2);

-- full form
SET @temp = @cur_bal * 0.06 / 12.00;
SET @temp = ROUND(@temp,2);
SET @temp = 500 - @temp;
SET @new_bal = @cur_bal - @temp;
SELECT
	@new_bal Balance,
	FORMAT(@new_bal, 'C') 'Format money';

-- short form
SET @new_bal = 
	@cur_bal - (500.00 - ROUND(@cur_bal * 
		0.06 / 12.00, 2));
SELECT
	@new_bal Balance,
	FORMAT(@new_bal, 'C') 'Format money';
GO



--------------------------------------------------------
-- Casting Between Data Types

DECLARE @v1 float(1) = 123.456;
DECLARE @v2 decimal(4,1) = 12.9;
DECLARE @v3 CHAR(4) = '3456';
DECLARE @v4 INT = 6;

SELECT @v1, CAST(@v1 AS real)
UNION ALL
SELECT @v2, CAST(@v2 AS decimal(5,2))
UNION ALL
SELECT @v3, CAST(@v3 AS INT)
UNION ALL
SELECT @v3, CAST(@v3 AS real)
UNION ALL
SELECT @v3, CAST(@v3 AS decimal(4));
GO

DECLARE @v4 INT = 6;
SELECT @v4/100
UNION ALL
SELECT
	CAST(@v4 AS DECIMAL(1,0)) / 
	CAST(100 AS DECIMAL(3,0))
UNION ALL
SELECT
	CAST(@v4 AS float) / 
	CAST(100.0 AS float);
GO


--------------------------------------------------------
-- Converting Numbers to Text
USE AdventureWorks2019
GO

SELECT  TOP 10
	ProductID, Name,
	ListPrice,
	CONVERT(NVARCHAR, ListPrice, 1) AS 'TPrice',
	Weight,
	CONVERT(NVARCHAR, Weight) AS 'TWeight'
FROM Production.Product
WHERE ListPrice > 0 AND Weight IS NOT NULL;
GO


--------------------------------------------------------
-- Converting from Text to a Number
USE AdventureWorks2019
GO

SELECT TOP 10
	NationalIDNumber,
	NationalIDNumber * 10 AS 'ID * 10',
	NationalIDNumber + ' AB'AS 'String concat',
	'-' + NationalIDNumber 'concat neg'
FROM HumanResources.Employee;
GO
-- Use CAST  
SELECT SUBSTRING(Name, 1, 30) AS ProductName, ListPrice  
FROM Production.Product  
WHERE CAST(ListPrice AS int) LIKE '33%';  
GO  
-- Use CONVERT.  
SELECT SUBSTRING(Name, 1, 30) AS ProductName, ListPrice  
FROM Production.Product  
WHERE CONVERT(int, ListPrice) LIKE '33%';  
GO  





