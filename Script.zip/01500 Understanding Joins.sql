/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- Inner Join query
USE AdventureWorks2019
GO

SELECT 
	p.ProductID, p.Name, p.Color, p.ListPrice,
	i.Bin, i.Quantity, i.Shelf
FROM Production.Product p
	INNER JOIN Production.ProductInventory i
		ON i.ProductID = p.ProductID
GO



--------------------------------------------------------------
-- Query with ambiguity in Join Columns
USE pubs
GO

SELECT * FROM titles
	JOIN titleauthor ON titles.title_id = titleauthor.title_id
	JOIN authors ON titleauthor.au_id = authors.au_id
	JOIN publishers ON titles.pub_id = publishers.pub_id;
GO

-- Resolving Ambiguity in Join Columns
USE pubs
GO

SELECT
	t.title_id, t.title, a.au_lname, 
	a.city AS [author city], 
	p.pub_name, p.city AS [publisher city]
FROM titles AS t
	JOIN titleauthor AS ti ON t.title_id = ti.title_id
	JOIN authors AS a ON ti.au_id = a.au_id
	JOIN publishers AS p ON t.pub_id = p.pub_id;
GO





--------------------------------------------------------------
-- Full outer joins
USE AdventureWorks2019
GO

SELECT 
	s.SalesOrderID, 
	s.SubTotal,
	c.CardNumber,
	c.CardType
FROM Sales.SalesOrderHeader s
	FULL OUTER JOIN Sales.CreditCard AS c 
		ON s.CreditCardID = c.CreditCardID;
GO

SELECT COUNT(*) AS [Sales Order Header row count]
FROM Sales.SalesOrderHeader 
GO

SELECT COUNT(*) AS [Credit card row count]
FROM Sales.CreditCard
	
GO



--------------------------------------------------------------
-- Cross join
USE pubs
GO

SELECT
	p.pub_id, pub_name, d.discounttype
FROM publishers p CROSS JOIN discounts d
WHERE pub_id IN(0736, 0877, 1389)
ORDER BY pub_id
GO


--------------------------------------------------------------
-- Using Self join to find customer in the same city

USE Northwind
GO

SELECT 
	A.CompanyName AS CustomerName1, 
	B.CompanyName AS CustomerName2, 
	A.City
FROM Customers A, Customers B
WHERE A.CustomerID <> B.CustomerID AND A.City = B.City
ORDER BY A.City;
GO





