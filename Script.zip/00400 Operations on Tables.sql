/*
    Getting started SQL 
    Loy Vanich 2021
*/


---------------------------------------------
-- Create table with auto increment
CREATE TABLE Persons (
    ID int IDENTITY(1,1) PRIMARY KEY,
    Name varchar(30) NOT NULL,
    Sex varchar(1),
    Age int
);


---------------------------------------------
-- Insert row with out ID data
USE mytest
GO

INSERT INTO Persons(Name, Sex, Age) VALUES ('Alice', 'F', 10);
INSERT INTO Persons(Name, Sex, Age) VALUES ('Tom', 'M', 9);
INSERT INTO Persons(Name, Sex, Age) VALUES ('Jan', 'F', 11);
INSERT INTO Persons(Name, Sex, Age) VALUES ('Bob', 'M', 8);

GO

SELECT * FROM Persons;
GO

---------------------------------------------
-- Adding a column to table
ALTER TABLE Persons
ADD Email varchar(20);
GO

SELECT * FROM Persons;
GO

---------------------------------------------
-- Modify column value
UPDATE Persons
	SET Email = 'alice@aaa.com' WHERE ID = 1;
GO

SELECT * FROM Persons;
GO

---------------------------------------------
-- List all table
USE mytest
GO

SELECT * FROM
    information_schema.tables;
GO


---------------------------------------------
-- Rename table
USE mytest
GO

EXEC sp_rename 'Persons', 'Employee';  
GO  

SELECT * FROM
    information_schema.tables;
GO

SELECT * FROM Employee;
GO


---------------------------------------------
-- Rename column (from Sex to Gender)
USE mytest
GO

EXEC sp_rename 'Employee.Sex', 'Gender', 'COLUMN';  
GO

SELECT * FROM Employee;
GO


---------------------------------------------
-- Drop column
USE mytest
GO

ALTER TABLE Employee
	DROP COLUMN ContactName;

SELECT * FROM Employee;
GO
