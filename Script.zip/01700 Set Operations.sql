/*
    Getting started SQL 
    Loy Vanich 2021
*/


-- UNION example query
USE pubs
GO

SELECT COUNT(*) FROM authors;
GO

SELECT COUNT(*) FROM publishers;
GO

-- UNION not include duplicate value
SELECT au_id, au_fname FROM authors
UNION
SELECT pub_id, pub_name FROM publishers;
GO

-- UNION ALL include duplicate value
SELECT au_id, au_fname FROM authors
UNION ALL
SELECT pub_id, pub_name FROM publishers;
GO


---------------------------------------------------
-- INTERSECT example query
USE pubs
GO

SELECT ord_num, ord_date, payterms FROM sales 
WHERE ord_date BETWEEN '1993/5/1' AND '1994/1/1';
GO

SELECT ord_num, ord_date, payterms FROM sales 
WHERE ord_date BETWEEN '1994/1/1' AND '1996/1/1';
GO

SELECT payterms FROM sales 
WHERE ord_date BETWEEN '1992/1/1' AND '1994/1/1'
INTERSECT
SELECT payterms FROM sales 
WHERE ord_date BETWEEN '1994/1/1' AND '1996/1/1';
GO


---------------------------------------------------
-- EXCEPT example query
USE pubs
GO

SELECT ord_num, ord_date, payterms FROM sales 
WHERE ord_date BETWEEN '1994/1/1' AND '1996/1/1';
GO

SELECT ord_num, ord_date, payterms FROM sales 
WHERE ord_date BETWEEN '1992/5/1' AND '1993/1/1';
GO

SELECT payterms FROM sales 
WHERE ord_date BETWEEN '1994/1/1' AND '1996/1/1'
EXCEPT
SELECT payterms FROM sales 
WHERE ord_date BETWEEN '1992/1/1' AND '1993/1/1';
GO


---------------------------------------------------
-- Using INTO with Set Operations
USE Northwind
GO

SELECT country, region, city INTO #T FROM Suppliers
EXCEPT
SELECT country, region, city FROM Employees
INTERSECT
SELECT country, region, city FROM Customers;


SELECT * FROM #T
WHERE Region IS NOT NULL
GO

DROP TABLE #T;
GO



