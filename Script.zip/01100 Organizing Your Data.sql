/*
    Getting started SQL 
    Loy Vanich 2021
*/


  USE NormalTest
  GO

  SELECT * FROM Store;
  GO

  SELECT s.StoreID, 
		s.OpenYear, 
		si.Name, 
		m.Name AS Manager, 
		c.Name AS City
  FROM Store s
	JOIN StoreInfo AS si ON s.StoreInfoID = si.StoreInfoID
	JOIN Manager AS m ON s.ManagerID = m.ManagerID
	JOIN City AS c ON s.CityID = c.CityID
  GO
  
  