/*
    Getting started SQL 
    Loy Vanich 2021
*/



-- Returning the Current Date and Time
SELECT 'GETDATE()' AS [Function], GETDATE() AS [Value];
SELECT 'CURRENT_TIMESTAMP'AS [Function], CURRENT_TIMESTAMP AS [Value];
SELECT 'GETUTCDATE()' AS [Function], GETUTCDATE() AS [Value];
SELECT 'SYSDATETIME()' AS [Function], SYSDATETIME() AS [Value];
SELECT 'SYSUTCDATETIME()' AS [Function], SYSUTCDATETIME() AS [Value];
SELECT 'SYSDATETIMEOFFSET()' AS [Function], SYSDATETIMEOFFSET() AS [Value];
GO


--------------------------------------------------------------------------------
-- Converting Between Time Zones

DECLARE @thai TIME = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+07:00');
DECLARE @Germany TIME = SWITCHOFFSET(SYSDATETIMEOFFSET(), '+02:00');

SELECT
	Thai = @thai, 
	'Thai AM/PM' = CONVERT(VARCHAR(10),  @thai, 0);

SELECT
	Germany = @Germany, 
	'Germany AM/PM' = CONVERT(VARCHAR(10),  @Germany, 0);
GO



--------------------------------------------------------------------------------
-- Converting a Date/Time Value to a Datetimeoffset Value

SELECT	TODATETIMEOFFSET(GETDATE(), '+07:00') 
			AS [Thiland Time Zone],
		SYSDATETIMEOFFSET()
			AS [Current System Time];

USE AdventureWorks2019
GO

SELECT TOP 5 
	ProductID, ModifiedDate,
	TODATETIMEOFFSET(ModifiedDate, '+07:00') 
			AS [Thiland Time Zone]
FROM Production.ProductInventory;
GO



--------------------------------------------------------------------------------
-- Incrementing or Decrementing a Date’s Value

SELECT DATEADD(YEAR, 1, '2009-04-02T00:00:00');
GO

USE AdventureWorks2019
GO

SELECT TOP 5 
	ProductID, ModifiedDate,
	DATEADD(YEAR, 1, ModifiedDate)
			AS [Add year]
FROM Production.ProductInventory;
GO


--------------------------------------------------------------------------------
-- Finding the Difference Between Two Dates

SELECT 
	Year = DATEDIFF(YEAR, '2019-04-02T00:00:00', GETDATE()),
	Month = DATEDIFF(MONTH, '2019-04-02T00:00:00', GETDATE()),
	Day = DATEDIFF(Day, '2019-04-02T00:00:00', GETDATE());
GO

USE AdventureWorks2019
GO

SELECT 
	DISTINCT(ProductID), 
	ModifiedDate,
	Year = DATEDIFF(YEAR, ModifiedDate, GETDATE()),
	Month = DATEDIFF(MONTH, ModifiedDate, GETDATE()),
	Day = DATEDIFF(Day, ModifiedDate, GETDATE())
FROM Production.ProductInventory
WHERE ProductID IN (531, 530, 997)
GO


--------------------------------------------------------------------------------
-- Displaying the String Value for Part of a Date

USE AdventureWorks2019
GO

SELECT 
	DISTINCT(ProductID), 
	ModifiedDate,
	DATENAME(MONTH, ModifiedDate) AS MonthName,
	DATENAME(WEEKDAY, ModifiedDate) AS WeekDayName
FROM Production.ProductInventory
WHERE ProductID IN (531, 530, 997);
GO









